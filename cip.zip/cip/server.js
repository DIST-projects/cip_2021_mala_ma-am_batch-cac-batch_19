const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');



app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended: true}));

app.use('/static',express.static('public'));
app.set('view engine', 'ejs');
app.set('views','views'); 
var mysql = require('mysql');


var HOST = 'localhost';
var PORT = 3306
var MYSQL_USER = 'root';
var MYSQL_PASS = '';
var DATABASE = 'cac';
var TABLE = 'info'; 
var TABLE1 = 'customer'; 
var TABLE2 = 'crop_production_tn';
var TABLE3 = 'sellcrop';

var mysql = mysql.createConnection({
host: HOST,
port: PORT,
user: MYSQL_USER,
password: MYSQL_PASS,
database: DATABASE
});

 
app.get('/',function(req,res){

    res.sendFile('index.html',{root: __dirname});
});


app.get('/accountcust',function(req,res)
{
	res.sendFile('accountcust.html',{root: __dirname});
});
app.get('/accountfarm',function(req,res)
{
	res.sendFile('accountfarm.html',{root: __dirname});
});
	
app.get('/signfarm',function(req,res)
{
	res.sendFile('signfarm.html',{root: __dirname});

});
app.get('/signcust',function(req,res)
{
	res.sendFile('signcust.html',{root: __dirname});

});
app.get('/searchcrop',function(req,res)
{
	res.sendFile('searchcrop.html',{root: __dirname});
});

app.get('/choice',function(req,res)
{
  res.sendFile('choice.html',{root: __dirname});
});

app.get('/choice_next1', function(req, res) {

   res.sendFile('searchcrop.html',{root: __dirname});

  });
app.get('/signedfarm', function(req, res) {

   res.sendFile('signedfarm.html',{root: __dirname});

  });

app.get('/sellcrop', function(req, res) {

   res.sendFile('sellcrop.html',{root: __dirname});

  });


app.post('/account_farm', function(req, res) {
console.log('req.body');

mysql.query("Insert into "+TABLE+" (name,email,password,confirm_pass,contactNo) VALUES ('"+req.body.name+"','"+req.body.email+"','"+req.body.password+"','"+req.body.confirm_pass+"','"+req.body.contactNo+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
   else
    res.sendFile('signedfarm.html',{root: __dirname});
});

});

app.post('/account_cust', function(req, res) {
console.log('req.body');
mysql.query("Insert into "+TABLE1+" (name,email,password,confirm_pass,contactNo) VALUES ('"+req.body.name+"','"+req.body.email+"','"+req.body.password+"','"+req.body.confirm_pass+"','"+req.body.contactNo+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
   else
    res.sendFile('signcust.html',{root: __dirname});
});
});

app.post('/sellcrop', function(req, res) {
console.log('req.body');
mysql.query("Insert into "+TABLE3+" (seller,cropname,cost,district,contact) VALUES ('"+req.body.seller+"','"+req.body.cropname+"','"+req.body.cost+"','"+req.body.district+"','"+req.body.contact+"')",function(err, result)      
{                                                      
  if (err)
     throw err;
   else
    res.sendFile('index.html',{root: __dirname});

});

});



app.post('/search_crop',function(req, res, next) {
console.log('crop');
console.log(req.body.state);
console.log(req.body.district);
console.log(req.body.season);

console.log("connected");
var sql = ("select crop from "+TABLE2+" WHERE state_name = '"+req.body.state+"' && district_name = '"+req.body.district+"' && season = '"+req.body.season+"'");

mysql.query(sql,function(err, result)      
{                                                      
  if (err)throw err;
  else
    console.log(result);
    res.render('b',{datas:result});
});			
});


app.post('/buy_crop',function(req, res, next) {
console.log('buycrop');
console.log("connected");
var sql = ("select * from "+TABLE3+" ");

mysql.query(sql,function(err, result)      
{                                                      
  if (err)throw err;
  else
    console.log(result);
    res.render('buy',{datas:result});
});     
});



app.listen(5000);

